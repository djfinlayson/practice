# oTree's default imports
from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
# import the "random" library for random variates, etc.
import random

# author of the oTree app
author = 'Felix Holzmeister'

# 'documentation' of the app
doc = """
    Single player investment game with a risky (normally distributed) and a risk-free asset
    for an arbitrary number of periods with graphical feedback on a player's wealth.
"""


# class constants
# ----------------------------------------------------------------------------------------------------------------------
class Constants(BaseConstants):
    # the 'constants' class defines parameters that are the same for all players and all rounds
    # constants should be treated like this and should not be changed, redefined, etc.
    # the first three constants defined below are required by oTree
    # the remaining ones are specific to the particular app

    # app's name in URL
    name_in_url = 'InvestmentGame'

    # number of players per group (<None> in case of single player games)
    players_per_group = None

    # numbers of rounds to be played
    num_rounds = 8

    # initial endowment for the investment game (in currency units)
    endowment = c(12)

    # risk-free rate (in %)
    rf = 2.35

    # risky asset
    mu = 10.25
    sig = 17.3


# class subsession
# ----------------------------------------------------------------------------------------------------------------------
class Subsession(BaseSubsession):

    def before_session_starts(self):
        for p in self.get_players():
            # draw random return for the risky asset from a normal with mu and sigma defined in constants
            p.r_ret = round(random.normalvariate(Constants.mu, Constants.sig), 4)

            # only in first period...
            if self.round_number == 1:
                # set initial portfolio wealth to initial endowment
                p.pf_iw = Constants.endowment
                # initialize list of wealth (for figure)
                p.participant.vars['wealth'] = [Constants.endowment]


# class group
# ----------------------------------------------------------------------------------------------------------------------
class Group(BaseGroup):
    pass


# class player
# ----------------------------------------------------------------------------------------------------------------------
class Player(BasePlayer):

    # pf_iw  >>> initial wealth
    pf_iw = models.CurrencyField()
    # pf_ew  >>> end-of-period wealth
    pf_ew = models.CurrencyField()

    # r_ret  >>> risky return
    r_ret = models.FloatField()
    # r_inv  >>> risky investment (in %)
    r_inv = models.IntegerField(min=0, max=200)

    # ..............................................
    # define a method to calculate a player's wealth
    # and store data in model fields
    # ..............................................
    def set_wealth(self):
        # profit/loss from risky asset
        r_pl = (self.r_inv/100 * self.pf_iw) * (self.r_ret / 100)

        # profit/loss from risk-free asset
        rf_pl = ((100 - self.r_inv)/100 * self.pf_iw) * (Constants.rf / 100)

        # payoff from this period
        self.payoff = r_pl + rf_pl

        # end-of-period value of portfolio
        self.pf_ew = self.pf_iw + self.payoff

        # set initial wealth of next period to end-of-period wealth of current period
        if self.subsession.round_number < Constants.num_rounds:
            next = self.subsession.round_number + 1
            self.in_round(next).pf_iw = self.pf_ew

        # append end-of-period wealth to global list 'wealth' for figure
        self.participant.vars['wealth'].append(self.pf_ew)
