# oTree's default imports
# add additional imports below if needed
from otree.api import Currency as c, currency_range, safe_json
from . import models
from ._builtin import Page, WaitPage
from .models import Constants


# the file 'views.py' defines a 'page' class for each of the html-templates
# the name of the classes should correspond to the names of the template files


# 'vars_for_all_templates(self)' allows to define variables passed to all templates
# whenever one or more variables are required by more than one view, the method mitigates redundancies
# in this case, we pass a list of wealth and a static list of periods to templates (for figure)
def vars_for_all_templates(self):
    return {
        'period': [i for i in range(0, Constants.num_rounds + 1)],
        'wealth': safe_json(self.player.participant.vars['wealth'])
        # 'safe_json()' does "jsonify" the list for use with javascript
    }


# page instructions
# ----------------------------------------------------------------------------------------------------------------------
class Instructions(Page):

    # the 'is_displayed(self)' method can be used to condition the display of a page
    # the respective page will only be displayed in subsessions when the method returns 'True'
    # in this case, we want to condition on the round number as instructions should only be displayed in round 1
    def is_displayed(self):
        # note that the statement will return 'True' if the condition is met and 'False' otherwise
        return self.subsession.round_number == 1


# page investment
# ----------------------------------------------------------------------------------------------------------------------
class Investment(Page):

    # form fields --> investment decision on player level
    form_model = models.Player
    form_fields = ['r_inv']

    # previous rounds results for summary table and figure
    def vars_for_template(self):
        return {
            'previous_rounds': self.player.in_previous_rounds()
        }

    # the method 'before_next_page()' allows for executing code before proceeding to the next view
    # by defining methods in models.py, this method allows to run calculations, group rematchings, etc.
    def before_next_page(self):
        # set player's variables by executing the 'set_wealth()'-method defined in models.py
        self.player.set_wealth()


# page results
# ----------------------------------------------------------------------------------------------------------------------
class Results(Page):
    # previous rounds results for summary table and figure
    def vars_for_template(self):
        return {
            'r_inv':  self.player.r_inv,
            'rf_inv': 100 - self.player.r_inv,
            'r_ret':  self.player.r_ret,
            'rf_ret': Constants.rf,
            'r_pl':   self.player.pf_iw * (self.player.r_inv / 100) * (self.player.r_ret / 100),
            'rf_pl':  self.player.pf_iw * ((100 - self.player.r_inv) / 100) * (Constants.rf / 100),
        }


# page final results
# ----------------------------------------------------------------------------------------------------------------------
class FinalResults(Page):

    # only display final results in last period
    def is_displayed(self):
        return self.subsession.round_number == Constants.num_rounds

    # all rounds' results for summary table and figure
    def vars_for_template(self):
        return {
            'all_rounds': self.player.in_all_rounds(),
            'final_payoff': self.player.pf_ew
        }


# sequence of pages
# ----------------------------------------------------------------------------------------------------------------------

# 'page_sequence' defines the list of pages to be displayed
# the ordering of pages (as displayed to the players) is determined by the ordering within the list
page_sequence = [
    Instructions,
    Investment,
    Results,
    FinalResults
]
