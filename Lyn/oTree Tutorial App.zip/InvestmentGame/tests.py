from otree.api import Currency as c, currency_range
from . import views
from ._builtin import Bot
from .models import Constants
import random

# player bot
# ----------------------------------------------------------------------------------------------------------------------
class PlayerBot(Bot):

    # the method 'play_round' simulates a the inputs of a participant for each view/page
    # for each page, the 'yield' command submits inputs for fields and the page itself
    def play_round(self):

        # submit instructions in round 1
        if self.subsession.round_number == 1:
            yield (views.Instructions)

        # submit a random integer between 0 and 200 for the investment decision
        yield (views.Investment, {'r_inv': random.randrange(0, 200)})

        # submit the results overview
        yield (views.Results)
