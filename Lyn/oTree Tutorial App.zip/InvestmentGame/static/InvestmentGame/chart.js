$(function () {
    $('#container').highcharts({
        chart: {
            ignoreHiddenSeries: false,
            type: 'line'
        },
        title: {
            text: ''
        },
        credits: {
            enabled: false
        },
        xAxis: {
            title: {
                text: 'Round No.'
            },
            categories: period
        },
        yAxis: {
            title: {
                text: ''
            },
            min: 0,
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            animation: true,
            formatter: function () {
                return 'your wealth in period no. ' + this.x +
                    ': <br/><b>' + this.y.toFixed(2) + '</b>';
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: 'Wealth',
            data: wealth,
            shadow: true
        },{
            name: 'Hidden',
            data: period,
            visible: false
        }]
    });
});